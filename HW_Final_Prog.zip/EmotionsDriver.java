import java.util.Scanner;
/**
 * EmotionsDriver class is just the main method that calls Emotions2 methods
 * Survey will run once before asking if the user wants to take it again.
 * 
 * @author (Yaphet Russom)
 * @version (3/10/2021)
 */
public class EmotionsDriver
{   
    public static void main(String[]args){
        //create objects
        Emotions test = new Emotions("Emotions.txt");
        Emotions2 test2 = new Emotions2();
        
        //test method
        //test.testFileIO();
        
        String response = ""; //check if they want want another another quote 
        
        //get at least one verse from user before asking if they want another verse  
        do{
            Scanner scan = new Scanner(System.in);
            //display the menu 
            test2.introduction(); 
            
            //get user input and display quote             
            test2.getUserInput(test);  
            
            //prompt user if they want another quote
            System.out.println("Do you want to do another test? (y/n)");
            response = scan.next();
            while(!response.equals("y") && !response.equals("n")){
                System.out.println("Invalid input please enter (y/n)");
                response = scan.next();
            }
        }
        while(response.equals("y"));
        
        System.out.println("Goodbye!");        
    }
}
