import java.util.Scanner;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.File;
/**
 * Emotions file reads in the bible verse from each file 
 * and saves it to appropriate emotion.
 * 
 * Program is a mental health survey that gets user input on how they are feeling 
 * and gives them appropriate bible verse from the file.
 * Assumes Emotions file is saved in same file.
 *
 * @author (Yaphet Russom)
 * @version (3/10/2021)
 */
public class Emotions
{
    // instance variables of all emotions 
    private String happy; 
    private String sad;
    private String excited;
    private String anxious;
    private String angry; 
    private String fear; 
    private String lonely;
    private String confusion;
    private String shame;

    /*
     * Emotions 
     * -------------
     * Constructor that reads one line from file and sets all instance variables
     * @param is String line from text file     
     */
    public Emotions(String Line){
        Scanner file = null;        
        Scanner scan = null;

        try{
            file = new Scanner(new FileInputStream(Line));
            scan = new Scanner(new FileInputStream(Line)); //read file          

            String []Emotions = new String[9]; //store all emotions in array

            int i = 0;           
            while(scan.hasNextLine()){ 
                if(i<Emotions.length){ //to make sure we dont read after end of file
                    Emotions[i] = scan.nextLine(); //store quote in array
                    i++;
                }         
                else{
                    break;
                }
            }
            //store the quotes into each emotion 
            this.happy = Emotions[0];
            this.sad =  Emotions[1];
            this.excited = Emotions[2];
            this.anxious =  Emotions[3];
            this.angry =  Emotions[4];
            this.fear =  Emotions[5];
            this.lonely =  Emotions[6];
            this.confusion =  Emotions[7];
            this.shame =  Emotions[8];
        }
        catch(Exception e){
            System.out.println("Error file not found");
        }
    }

    /*
     * TestFileIO
     * ------------
     * Test method to see if files got read in correctly
     */
    public void testFileIO(){
        Emotions test = new Emotions("Emotions.txt");

        System.out.println("Testing File IO now\n");
        
        System.out.println("Happy should print Romans 15:13 verse: ");
        System.out.println(test.getHappy()+"\n"); 
        
        System.out.println("Sad should print Psalms 126:5 verse: ");
        System.out.println(test.getSad()+"\n");
        
        System.out.println("Excited should print Philippians 4:4 verse: ");
        System.out.println(test.getExcited()+"\n");
        
        System.out.println("Anxious should print Matthew 6:25 verse: ");
        System.out.println(test.getAnxious()+"\n");
        
        System.out.println("Angry should print Psalms 37:8 verse: ");
        System.out.println(test.getAngry()+"\n");
        
        System.out.println("Fear should print 2 Timothy 1:7 verse: ");
        System.out.println(test.getFear()+"\n");
        
        System.out.println("Lonely should print Romans 8:37 verse: ");
        System.out.println(test.getLonely()+"\n");
        
        System.out.println("Confusion should print 1 Corinthians 14:33  verse: ");
        System.out.println(test.getConfusion()+"\n");
        
        System.out.println("Shame should print Romans 8:1 verse: ");
        System.out.println(test.getShame()+"\n");
        
    }

    // accessor methods for emotions 

    public String getHappy(){
        return this.happy;
    }

    public String getSad(){
        return this.sad;
    }

    public String getExcited(){
        return this.excited;
    }

    public String getAnxious(){
        return this.anxious;
    }

    public String getAngry(){
        return this.angry;
    }

    public String getFear(){
        return this.fear;
    }

    public String getLonely(){
        return this.lonely;
    }

    public String getConfusion(){
        return this.confusion;
    }

    public String getShame(){
        return this.shame;
    }
}
