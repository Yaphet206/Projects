import java.util.Scanner;
/**
 * Emotions2 class promts user then get user input. Acesses Emotions class
 * and prints out verses that were stored in the appropriate emotion.
 *
 * @author (Yaphet Russom)
 * @version (3/10/2021)
 */
public class Emotions2
{   
    /*
     * introduction
     * --------------
     * Introduces user to survey and creates list of emotions listed
     * no param and doesn't return anything
     */
    public void introduction(){        
        String[]Emotions = {"happy","sad","excited","anxious","angry","fear","lonely","confusion","shame"};

        System.out.println("Welcome to the mental health survey!");
        System.out.println("-------------------------------------");

        for(int i = 0; i<Emotions.length; i++){
            System.out.println((i+1)+": "+Emotions[i]);
        }  
    }
    
     /*
     * isNumberValid
     * ---------------
     * Method checks is passed in number is valid
     * number is valid if (1-9)
     * reprompt user and returns until valid number
     * @param is int for user input
     * PRECONDTION: User must type number
     * 
     */
    public int getValidNumber(int user){
        Scanner scan2 = new Scanner(System.in);

        while(user<1 || user>9){
            System.out.println("Invalid input please enter number (1-9)");
            user = scan2.nextInt();
        }    

        return user;
    }

    /*
     * getUserInput
     * -------------
     * Method promts user to enter number (1-9)
     * number is equivalent to emotion 
     * @param is Emotions class
     * call is number valid so there is a valid number in the if statement
     */
    public void getUserInput(Emotions e){
        System.out.println("Enter the number equivalent to how your feeling (1-9)");        
        Scanner scan = new Scanner(System.in);

        int user = scan.nextInt(); 
        user = getValidNumber(user); //passes in user input 
        
        
        //check if user input is 1-9 
        //print appropriate verse within if statements
        if(user == 1){
            System.out.println(e.getHappy());
        }
        else if(user == 2){
            System.out.println(e.getSad());
        }
        else if(user == 3){
            System.out.println(e.getExcited());
        }
        else if(user == 4){
            System.out.println(e.getAnxious());
        }
        else if(user == 5){
            System.out.println(e.getAngry());
        }
        else if(user == 6){
            System.out.println(e.getFear());
        }
        else if(user == 7){
            System.out.println(e.getLonely());
        }
        else if(user == 8){
            System.out.println(e.getConfusion());
        }
        else if(user == 9){
            System.out.println(e.getShame());
        }
    }
}

